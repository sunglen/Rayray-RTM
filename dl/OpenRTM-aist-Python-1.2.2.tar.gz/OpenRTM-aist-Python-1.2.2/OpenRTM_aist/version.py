#!/usr/bin/env python3
# -*- coding: euc-jp -*-

openrtm_name    = "OpenRTM-aist-1.2.2"
openrtm_version = "1.2.2"
corba_name      = "omniORB"
