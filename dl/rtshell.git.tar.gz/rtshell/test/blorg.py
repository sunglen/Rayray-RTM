a = 'blorg'

def format(data):
    return 'formatted'

