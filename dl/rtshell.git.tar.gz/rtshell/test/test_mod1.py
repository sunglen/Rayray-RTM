a = '1'

class Dummy(object):
    def __init__(self, param1, param2):
        self.param1 = param1
        self.param2 = param2
