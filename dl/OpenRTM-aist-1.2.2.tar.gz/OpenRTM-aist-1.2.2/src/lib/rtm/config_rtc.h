/* src/lib/rtm/config_rtc.h.  Generated from config_rtc.h.in by configure.  */
/* src/lib/rtm/config_rtc.h.in.  Generated from configure.ac by autoheader.  */

/* ARTLinux is avaiable */
/* #undef ARTLINUX */

/* Build ext/logger/fluentbit_stream */
#ifndef BUILD_EXTFLUENTD
#define BUILD_EXTFLUENTD FALSE
#endif // BUILD_EXTFLUENTD

/* Build ext/sdo */
#ifndef BUILD_EXTOBSERVER
#define BUILD_EXTOBSERVER TRUE
#endif // BUILD_EXTOBSERVER

/* Build ext/ssl */
#ifndef BUILD_EXTSSL
#define BUILD_EXTSSL TRUE
#endif // BUILD_EXTSSL

/* Fluentd logger embedded. */
/* #undef ENABLE_FLUENTD */

/* Component Observer embedded. */
#ifndef ENABLE_OBSERVER
#define ENABLE_OBSERVER TRUE
#endif // ENABLE_OBSERVER

/* omniSSL is NOT used */
#ifndef ENABLE_OMNISSL
#define ENABLE_OMNISSL TRUE
#endif // ENABLE_OMNISSL

/* SSL transport embedded. */
#ifndef ENABLE_SSL
#define ENABLE_SSL TRUE
#endif // ENABLE_SSL

/* Define to 1 if you have the <dlfcn.h> header file. */
#ifndef HAVE_DLFCN_H
#define HAVE_DLFCN_H 1
#endif // HAVE_DLFCN_H

/* Define to 1 if you have the <inttypes.h> header file. */
#ifndef HAVE_INTTYPES_H
#define HAVE_INTTYPES_H 1
#endif // HAVE_INTTYPES_H

/* Define to 1 if you have the <memory.h> header file. */
#ifndef HAVE_MEMORY_H
#define HAVE_MEMORY_H 1
#endif // HAVE_MEMORY_H

/* Define to 1 if you have the <nlist.h> header file. */
/* #undef HAVE_NLIST_H */

/* Define to 1 if you have the <stdint.h> header file. */
#ifndef HAVE_STDINT_H
#define HAVE_STDINT_H 1
#endif // HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#ifndef HAVE_STDLIB_H
#define HAVE_STDLIB_H 1
#endif // HAVE_STDLIB_H

/* Define to 1 if you have the <strings.h> header file. */
#ifndef HAVE_STRINGS_H
#define HAVE_STRINGS_H 1
#endif // HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#ifndef HAVE_STRING_H
#define HAVE_STRING_H 1
#endif // HAVE_STRING_H

/* Define to 1 if you have the <sys/stat.h> header file. */
#ifndef HAVE_SYS_STAT_H
#define HAVE_SYS_STAT_H 1
#endif // HAVE_SYS_STAT_H

/* Define to 1 if you have the <sys/types.h> header file. */
#ifndef HAVE_SYS_TYPES_H
#define HAVE_SYS_TYPES_H 1
#endif // HAVE_SYS_TYPES_H

/* Define to 1 if you have the `uname' function. */
#ifndef HAVE_UNAME
#define HAVE_UNAME 1
#endif // HAVE_UNAME

/* Define to 1 if you have the <unistd.h> header file. */
#ifndef HAVE_UNISTD_H
#define HAVE_UNISTD_H 1
#endif // HAVE_UNISTD_H

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#ifndef LT_OBJDIR
#define LT_OBJDIR ".libs/"
#endif // LT_OBJDIR

/* ORB is MICO */
/* #undef ORB_IS_MICO */

/* ORB is omniORB */
#ifndef ORB_IS_OMNIORB
#define ORB_IS_OMNIORB TRUE
#endif // ORB_IS_OMNIORB

/* ORB is ORBacus */
/* #undef ORB_IS_ORBACUS */

/* ORB is ORBit2 */
/* #undef ORB_IS_ORBIT2 */

/* ORB is Orbix */
/* #undef ORB_IS_ORBIX */

/* ORB is RtORB */
/* #undef ORB_IS_RTORB */

/* ORB is TAO */
/* #undef ORB_IS_TAO */

/* Name of package */
/* #undef RTM_PACKAGE */

/* Define to the address where bug reports for this package should be sent. */
/* #undef RTM_PACKAGE_BUGREPORT */

/* Define to the full name of this package. */
/* #undef RTM_PACKAGE_NAME */

/* Define to the full name and version of this package. */
/* #undef RTM_PACKAGE_STRING */

/* Define to the one symbol short name of this package. */
/* #undef RTM_PACKAGE_TARNAME */

/* Define to the home page for this package. */
/* #undef RTM_PACKAGE_URL */

/* Define to the version of this package. */
/* #undef RTM_PACKAGE_VERSION */

/* Python wrapper is enable */
/* #undef PYTHON_WRAPPER */

/* CORBA C++ mapping is ver1.1 */
#ifndef RTC_CORBA_CXXMAPPING11
#define RTC_CORBA_CXXMAPPING11 TRUE
#endif // RTC_CORBA_CXXMAPPING11

/* Socket DataPort is enable */
/* #undef RTC_SOCK_DATAPORT */

/* RTM is compiled with gcc2 */
/* #undef RTM_GCC2 */

/* RTM major version */
#ifndef RTM_MAJOR_VERSION
#define RTM_MAJOR_VERSION 1
#endif // RTM_MAJOR_VERSION

/* RTM minor version */
#ifndef RTM_MINOR_VERSION
#define RTM_MINOR_VERSION 2
#endif // RTM_MINOR_VERSION

/* omniORB version is 4.0 */
/* #undef RTM_OMNIORB_40 */

/* omniORB version is 4.1 */
/* #undef RTM_OMNIORB_41 */

/* omniORB version is 4.2 */
#ifndef RTM_OMNIORB_42
#define RTM_OMNIORB_42 TRUE
#endif // RTM_OMNIORB_42

/* OS is Cygwin */
/* #undef RTM_OS_CYGWIN */

/* OS is Max OS X */
/* #undef RTM_OS_DARWIN */

/* OS is FreeBSD */
/* #undef RTM_OS_FREEBSD */

/* OS is HP-UX */
/* #undef RTM_OS_HPUX */

/* OS is IRIX */
/* #undef RTM_OS_IRIX */

/* OS is Linux */
#ifndef RTM_OS_LINUX
#define RTM_OS_LINUX TRUE
#endif // RTM_OS_LINUX

/* OS is OSF1 */
/* #undef RTM_OS_OSF1 */

/* OS is QNX */
/* #undef RTM_OS_QNX */

/* OS is SunOS */
/* #undef RTM_OS_SUNOS */

/* RTM revision numver */
#ifndef RTM_REVISION_NUM
#define RTM_REVISION_NUM 2
#endif // RTM_REVISION_NUM

/* RDTSC is enable */
/* #undef RTM_RTDSC */

/* RTM short version */
#ifndef RTM_SHORT_VERSION
#define RTM_SHORT_VERSION "122"
#endif // RTM_SHORT_VERSION

/* RTM version */
#ifndef RTM_VERSION
#define RTM_VERSION "1.2.2"
#endif // RTM_VERSION

/* Define to 1 if you have the ANSI C header files. */
#ifndef STDC_HEADERS
#define STDC_HEADERS 1
#endif // STDC_HEADERS

/* Version number of package */


/* Define if using the dmalloc debugging malloc package */
/* #undef WITH_DMALLOC */

/* Multi Thread Support */
#ifndef _REENTRANT
#define _REENTRANT TRUE
#endif // _REENTRANT
