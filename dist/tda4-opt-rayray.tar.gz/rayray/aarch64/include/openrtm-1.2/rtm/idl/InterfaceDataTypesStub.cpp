// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file  InterfaceDataTypesStub.cpp 
 * @brief InterfaceDataTypes server skeleton wrapper code
 * @date  Wed Apr 20 16:28:17 2022 
 *
 */

#include "rtm/idl/InterfaceDataTypesStub.h"

#if   defined ORB_IS_TAO
#include "rtm/idl/InterfaceDataTypesC.cpp"
#elif defined ORB_IS_OE
#include "rtm/idl/InterfaceDataTypes.cxx"
#elif defined ORB_IS_OMNIORB
#ifdef WIN32
#pragma warning( disable : 4267 )
#pragma warning( disable : 4290 )
#pragma warning( disable : 4311 )
#pragma warning( disable : 4312 )
#endif // WIN32
#include "rtm/idl/InterfaceDataTypesSK.cc"
#include "rtm/idl/InterfaceDataTypesDynSK.cc"
#ifdef WIN32
#pragma warning( default : 4267 )
#pragma warning( default : 4290 )
#pragma warning( default : 4311 )
#pragma warning( default : 4312 )
#endif // WIN32
#elif defined ORB_IS_MICO
#include "rtm/idl/InterfaceDataTypes.cc"
#elif defined ORB_IS_ORBIT2
#include "rtm/idl/InterfaceDataTypes-cpp-stubs.cc"
#elif defined ORB_IS_RTORB
#include "rtm/idl/InterfaceDataTypes-stubs.c"
#else
#error "NO ORB defined"
#endif
