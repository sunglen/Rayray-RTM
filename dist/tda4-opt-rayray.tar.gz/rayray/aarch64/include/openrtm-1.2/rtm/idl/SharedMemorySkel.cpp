// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file  SharedMemorySkel.cpp 
 * @brief SharedMemory server skeleton wrapper code
 * @date  Wed Apr 20 16:28:17 2022 
 *
 */

#include "rtm/idl/SharedMemorySkel.h"

#if   defined ORB_IS_TAO
#include "rtm/idl/SharedMemoryC.cpp"
#include "rtm/idl/SharedMemoryS.cpp"
#elif defined ORB_IS_OE
#include "rtm/idl/SharedMemory.cxx"
#include "rtm/idl/SharedMemory_s.cxx"
#elif defined ORB_IS_OMNIORB
#ifdef WIN32
#pragma warning( disable : 4267 )
#pragma warning( disable : 4290 )
#pragma warning( disable : 4311 )
#pragma warning( disable : 4312 )
#endif // WIN32
#include "rtm/idl/SharedMemorySK.cc"
#include "rtm/idl/SharedMemoryDynSK.cc"
#ifdef WIN32
#pragma warning( default : 4267 )
#pragma warning( default : 4290 )
#pragma warning( default : 4311 )
#pragma warning( default : 4312 )
#endif // WIN32
#elif defined ORB_IS_MICO
#include "rtm/idl/SharedMemory.cc"
#include "rtm/idl/SharedMemory_skel.cc"
#elif defined ORB_IS_ORBIT2
#include "rtm/idl/SharedMemory-cpp-skels.cc"
#include "rtm/idl/SharedMemory-cpp-stubs.cc"
#elif defined ORB_IS_RTORB
#include "rtm/idl/SharedMemory-common.c"
#include "rtm/idl/SharedMemory-stubs.c"
#include "rtm/idl/SharedMemory-skels.c"
#include "rtm/idl/SharedMemory-skelimpl.c"
#else
#error "NO ORB defined"
#endif
