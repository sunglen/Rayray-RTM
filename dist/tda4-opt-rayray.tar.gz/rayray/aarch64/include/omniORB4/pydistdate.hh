// distdate.hh -- Automatically generated file

#define OMNIORBPY_DIST_DATE "Mon 10 Dec 23:41:29 GMT 2018"
